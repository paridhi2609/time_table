package com.paridhi.time_table;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import android.widget.TextView;
import android.support.v7.widget.Toolbar;

public class MainActivity extends AppCompatActivity {
    private Toolbar toolbar;
    private ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupviews();
        inittoolbar();
    }
    private void setupviews(){
        toolbar=(Toolbar)findViewById(R.id.toolbar);
        listView=(ListView)findViewById(R.id.lvMain);
    }
    private void inittoolbar(){
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("timetable app");

    }
    private void setuplistview(){
        String[] title = getResources().getStringArray(R.array.main);
        String[] description = getResources().getStringArray(R.array.de);
        SimpleAdapter simpleAdapter = new SimpleAdapter(this, title, description);
        listView.setAdapter(simpleAdapter);
    }

    public class SimpleAdapter extends BaseAdapter{
        private Context mcontext;
        private LayoutInflater layoutinflater;
        private TextView title, description;
        private String[] titlearray;
        private String[] descriptionarray;
        private ImageView imageview;

        public SimpleAdapter(Context context, String[] title, String[] description){
            mcontext=context;
            titlearray=title;
            descriptionarray=description;
            layoutinflater=LayoutInflater.from(context);
        }
        @Override
        public int getCount() {
            return titlearray.length;
        }

        @Override
        public Object getItem(int position) {
            return titlearray[position];
        }

         @Override
         public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(convertView==null){
                convertView=layoutinflater.inflate(R.layout.main_activity_single_element,null);
            }
            title=(TextView)convertView.findViewById(R.id.txt1);
            description=(TextView)convertView.findViewById(R.id.txt2);
            imageview=(ImageView)convertView.findViewById(R.id.image);

            title.setText(titlearray[position]);
            description.setText(descriptionarray[position]);

            if(titlearray[position].equalsIgnoreCase("timetable"))
                imageview.setImageResource(R.drawable.timetable);
            else  if(titlearray[position].equalsIgnoreCase("subjects"))
                imageview.setImageResource(R.drawable.timetable);
            else  if(titlearray[position].equalsIgnoreCase("faculty"))
                imageview.setImageResource(R.drawable.timetable);
            else
                imageview.setImageResource(R.drawable.timetable);
            return convertView;
        }
    }
}
